
public class AppointmentTest.java {
	import org.junit.Test;
	import static org.junit.Assert.*;
	import java.util.Date;
	public class AppointmentServiceTest {
	private Date futureDate = new Date(System.currentTimeMillis() + 86400000);
	@Test
	public void testAddAndGetAppointment() {
	AppointmentService service = new AppointmentService();
	Appointment appt = new Appointment(&quot;APT123&quot;, futureDate, &quot;Checkup&quot;);
	service.addAppointment(appt);
	assertEquals(appt, service.getAppointment(&quot;APT123&quot;));
	}
	@Test(expected = IllegalArgumentException.class)
	public void testAddDuplicateAppointment() {
	AppointmentService service = new AppointmentService();
	Appointment appt1 = new Appointment(&quot;APT123&quot;, futureDate, &quot;Checkup&quot;);
	Appointment appt2 = new Appointment(&quot;APT123&quot;, futureDate, &quot;Cleaning&quot;);
	service.addAppointment(appt1);
	service.addAppointment(appt2);
	}
	// Add more tests for delete and edge cases
}
