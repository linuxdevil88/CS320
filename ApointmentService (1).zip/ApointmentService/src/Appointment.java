import java.util.Date;
public class Appointment {
private final String appointmentId; // Immutable
private Date appointmentDate;
private String description;
public Appointment(String appointmentId, Date appointmentDate, String description) {
// Validate ID
if (appointmentId == null || appointmentId.length() &gt; 10) {
throw new IllegalArgumentException(&quot;Appointment ID must be ≤10 characters and not
null&quot;);
}
// Validate date
if (appointmentDate == null || appointmentDate.before(new Date())) {
throw new IllegalArgumentException(&quot;Appointment date must be in the future and not
null&quot;);
}
// Validate description
if (description == null || description.length() &gt; 50) {
throw new IllegalArgumentException(&quot;Description must be ≤50 characters and not null&quot;);
}
this.appointmentId = appointmentId;
this.appointmentDate = new Date(appointmentDate.getTime()); // Defensive copy
this.description = description;
}
// Getters
public String getAppointmentId() { return appointmentId; }
public Date getAppointmentDate() {
return new Date(appointmentDate.getTime()); // Defensive copy
}
public String getDescription() { return description; }
// Setters (only for date and description)
public void setAppointmentDate(Date newDate) {
if (newDate == null || newDate.before(new Date())) {
throw new IllegalArgumentException(&quot;Appointment date must be in the future and not
null&quot;);
}
this.appointmentDate = new Date(newDate.getTime());
}
public void setDescription(String newDescription) {
if (newDescription == null || newDescription.length() &gt; 50) {
throw new IllegalArgumentException(&quot;Description must be ≤50 characters and not null&quot;);

}
this.description = newDescription;
}
}