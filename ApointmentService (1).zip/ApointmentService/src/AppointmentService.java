
public class AppointmentService.java {

	import java.util.HashMap;
	import java.util.Map;
	public class AppointmentService {
	private final Map&lt;String, Appointment&gt; appointments = new HashMap&lt;&gt;();
	public void addAppointment(Appointment appointment) {
	if (appointment == null || appointments.containsKey(appointment.getAppointmentId())) {
	throw new IllegalArgumentException(&quot;Appointment is null or ID already exists&quot;);
	}
	appointments.put(appointment.getAppointmentId(), appointment);
	}
	public void deleteAppointment(String appointmentId) {
	if (!appointments.containsKey(appointmentId)) {
	throw new IllegalArgumentException(&quot;Appointment ID not found&quot;);
	}
	appointments.remove(appointmentId);
	}
	public Appointment getAppointment(String appointmentId) {
	return appointments.get(appointmentId);
	}
	}
